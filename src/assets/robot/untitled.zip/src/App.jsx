import Spline from '@splinetool/react-spline';

export default function App() {
  return (
    <Spline scene="https://prod.spline.design/LtV1M9z6Ft-A18EK/scene.splinecode" />
  );
}
